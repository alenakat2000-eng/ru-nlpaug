
"""
ru_nlpaug.augmenter.word.back_translation

Русская обёртка над nlpaug.augmenter.word.BackTranslationAug.
Пока только подмена токенизации через RussianWordMixin.
Дальше вы добавите сюда свои словари / морфологию.
"""

# ru_nlpaug/augmenter/word/ru_back_translation.py

# ru_nlpaug/augmenter/word/ru_back_translation.py

from transformers import MarianMTModel, MarianTokenizer
import nlpaug.augmenter.word as naw
import os


class RuBackTranslationAug(naw.WordAugmenter):
    """Аугментация обратным переводом через локальные модели"""
    
    def __init__(
        self,
        models_dir: str = "models",
        intermediate_lang: str = "en",
        name: str = "RuBackTranslation_Aug",
        verbose: int = 0,
    ):
        super().__init__(
            action="substitute",
            name=name,
            aug_p=None,
            aug_min=None,
            aug_max=None,
            tokenizer=None,
            device="cpu",
            verbose=verbose,
            include_detail=False,
        )
        
        # Пути к локальным моделям
        ru_to_en_path = os.path.join(models_dir, "opus-mt-ru-en")
        en_to_ru_path = os.path.join(models_dir, "opus-mt-en-ru")
        
        # Проверяем что модели скачаны
        if not os.path.exists(ru_to_en_path):
            raise FileNotFoundError(
                f"❌ Модель не найдена: {ru_to_en_path}\n"
                f"   Скачайте с https://huggingface.co/Helsinki-NLP/opus-mt-ru-en"
            )
        if not os.path.exists(en_to_ru_path):
            raise FileNotFoundError(
                f"❌ Модель не найдена: {en_to_ru_path}\n"
                f"   Скачайте с https://huggingface.co/Helsinki-NLP/opus-mt-en-ru"
            )
        
        # Загружаем модели
        self.ru_to_en_tokenizer = MarianTokenizer.from_pretrained(ru_to_en_path)
        self.ru_to_en_model = MarianMTModel.from_pretrained(ru_to_en_path)
        
        self.en_to_ru_tokenizer = MarianTokenizer.from_pretrained(en_to_ru_path)
        self.en_to_ru_model = MarianMTModel.from_pretrained(en_to_ru_path)

    def substitute(self, data: str, n: int = 1) -> str:
        if not data or not data.strip():
            return data
        
        # Русский → Английский
        inputs = self.ru_to_en_tokenizer(
            data, 
            return_tensors="pt", 
            padding=True, 
            truncation=True,
            max_length=512
        )
        outputs = self.ru_to_en_model.generate(**inputs, max_length=512)
        intermediate = self.ru_to_en_tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Английский → Русский
        inputs = self.en_to_ru_tokenizer(
            intermediate, 
            return_tensors="pt", 
            padding=True,
            truncation=True,
            max_length=512
        )
        outputs = self.en_to_ru_model.generate(**inputs, max_length=512)
        result = self.en_to_ru_tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        return result
    
    # Алиас для совместимости
    def augment(self, data: str) -> str:
        return self.substitute(data)

