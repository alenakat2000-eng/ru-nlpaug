
"""
ru_nlpaug.util.text

Расширение nlpaug.util.text для русского языка.

- Подтягивает всё из nlpaug.util.text (английские утилиты).
- Добавляет ru_tokenize / ru_detokenize и свои POS-утилиты.
"""

# ru_nlpaug/util/text/__init__.py

from nlpaug.util.text import *

from .ru_tokenizer import (
    ru_tokenize,
    ru_detokenize,
    split_sentences,
    get_russian_stopwords
)

from .ru_part_of_speech import RussianMorphology

__all__ = [
    *[name for name in dir() if not name.startswith("_")],
]
