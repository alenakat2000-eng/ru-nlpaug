
"""
ru_nlpaug.util.text.rutokenizer

Русский токенизатор: razdel.

!!! Оригинальный код nplaug:

#######
### MODULE: nlpaug.util.text.tokenizer

import re

ADDING_SPACE_AROUND_PUNCTUATION_REGEX = re.compile(r'(?<! )(?=[.,!?()])|(?<=[.,!?()])(?! )')

SPLIT_WORD_REGEX = re.compile(r'\b.*?\S.*?(?:\b|$)')

TOKENIZER_REGEX = re.compile(r'(\W)')
DETOKENIZER_REGEXS = [
	(re.compile(r'\s([.,:;?!%]+)([ \'"`])'), r'\1\2'), # End of sentence
	(re.compile(r'\s([.,:;?!%]+)$'), r'\1'), # End of sentence
	(re.compile(r'\s([\[\(\{\<])\s'), r' \g<1>'), # Left bracket
	(re.compile(r'\s([\]\)\}\>])\s'), r'\g<1> '), # right bracket
]

SENTENCE_SEPARATOR = '.!?'

def add_space_around_punctuation(text):
    return ADDING_SPACE_AROUND_PUNCTUATION_REGEX.sub(r' ', text)

def split_sentence(text):
    return SPLIT_WORD_REGEX.findall(text)

class Tokenizer:
	@staticmethod
	def tokenizer(text):
		tokens = TOKENIZER_REGEX.split(text)
		return [t for t in tokens if len(t.strip()) > 0]

	@staticmethod
	def reverse_tokenizer(tokens):
		text = ' '.join(tokens)
		for regex, sub in DETOKENIZER_REGEXS:
			text = regex.sub(sub, text)
		return text.strip()

"""
from pathlib import Path
from typing import List, Set
from functools import lru_cache

from razdel import tokenize as razdel_tokenize
from razdel import sentenize as razdel_sentenize


# ──────────────────────────────────────────────────────────────
# 1.  ТОКЕНИЗАЦИЯ / ДЕТОКЕНИЗАЦИЯ
# ──────────────────────────────────────────────────────────────

# Наборы символов для склейки
PUNCT_NO_SPACE_BEFORE = {'.', ',', '!', '?', ':', ';', '...', '…', '%'}
CLOSING_BRACKETS      = {')', ']', '}', '»', '"', "'"}
OPENING_BRACKETS      = {'(', '[', '{', '«', '"', "'"}
DASHES                = {'—', '–'}
HYPHEN                = {'-'}


def ru_tokenize(text: str) -> List[str]:
    """Список токенов razdel."""
    if not text or not text.strip():
        return []
    return [t.text for t in razdel_tokenize(text)]


def ru_detokenize(tokens: List[str]) -> str:
    """Склеиваем токены обратно в строку."""
    if not tokens:
        return ""
    res: List[str] = [tokens[0]]
    for prev, cur in zip(tokens, tokens[1:]):
        need_space = True
        if cur in PUNCT_NO_SPACE_BEFORE or cur in CLOSING_BRACKETS:
            need_space = False
        elif prev in OPENING_BRACKETS:
            need_space = False
        elif cur in HYPHEN or prev in HYPHEN:
            need_space = False
        if need_space:
            res.append(' ')
        res.append(cur)
    return ''.join(res)


def split_sentences(text: str) -> List[str]:
    """Разбиваем на предложения razdel'ем."""
    if not text or not text.strip():
        return []
    return [s.text for s in razdel_sentenize(text)]


# ──────────────────────────────────────────────────────────────
# 2.  ЗАГРУЗКА СТОП-СЛОВ / СПИСКОВ
# ──────────────────────────────────────────────────────────────

_STOP_CACHE: dict[str, Set[str]] = {}


def _load_wordlist(fname: str) -> Set[str]:
    """
    Читает txt-файл из той же папки, что и tokenizer.py.
    Каждая строка → один элемент списка.
    """
    if fname in _STOP_CACHE:
        return _STOP_CACHE[fname]

    local_path = Path(__file__).with_suffix('').parent / fname
    if local_path.exists():
        words = {line.strip() for line in local_path.open(encoding='utf-8') if line.strip()}
        _STOP_CACHE[fname] = words
        return words

    # Файл не найден — возвращаем пустое множество
    _STOP_CACHE[fname] = set()
    return set()


@lru_cache(maxsize=1)
def get_russian_stopwords() -> Set[str]:
    """
    Собирает единый набор:
        stop.txt   + preps.txt + punct.txt
        pronouns.txt + usertop.txt
    Если какого-то файла нет — пропускаем.
    """
    stop      = _load_wordlist('stop.txt')
    preps     = _load_wordlist('preps.txt')
    pronouns  = _load_wordlist('pronouns.txt')
    punct = _load_wordlist('punct.txt')
    usertop   = _load_wordlist('usertop.txt')

    full = stop | preps | pronouns | punct | usertop
    return {w.lower() for w in full}


# ──────────────────────────────────────────────────────────────
# 3.  Совместимый с nlpaug класс-обёртка
# ──────────────────────────────────────────────────────────────

class Tokenizer:
    """Совместимость с интерфейсом nlpaug."""
    @staticmethod
    def tokenizer(text: str) -> List[str]:
        return ru_tokenize(text)

    @staticmethod
    def reverse_tokenizer(tokens: List[str]) -> str:
        return ru_detokenize(tokens)
