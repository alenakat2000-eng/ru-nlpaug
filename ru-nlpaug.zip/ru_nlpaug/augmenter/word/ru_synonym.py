"""
ru_nlpaug.augmenter.word.ru_synonym

Русский аугментатор замены слов на синонимы.
Использует словарь синонимов из репозитория Даши Бородиной (ruAntSynNet).
Поддерживает морфологическое согласование форм через RussianMorphology.
"""

import os
import csv
import random
from pathlib import Path
from typing import List, Dict, Optional, Set, Tuple

import nlpaug.augmenter.word as naw  # базовые аугментеры для слов
from nlpaug.util import Action  # типы действий (замена, вставка, удаление)

from ru_nlpaug.augmenter.word.base import RussianWordMixin  # подменяет токенизацию на русскую
from ru_nlpaug.util.text.ru_tokenizer import (
    ru_tokenize,  # функции из нашего модуля токенизации
    ru_detokenize,
    get_russian_stopwords,
)

# ──────────────────────────────────────────────────────────────
# Попытка импорта морфологии (stanza + pymorphy2)
# Если не установлены — работаем без согласования форм
# ──────────────────────────────────────────────────────────────
try:
    from ru_nlpaug.util.text.ru_part_of_speech import RussianMorphology
    _MORPH = RussianMorphology()
    _MORPH_AVAILABLE = True
except ImportError:
    _MORPH = None
    _MORPH_AVAILABLE = False


# ──────────────────────────────────────────────────────────────
# 1. Загрузка словаря
# ──────────────────────────────────────────────────────────────

# Кэш для словарей, чтобы не читать CSV каждый раз
_DICT_CACHE: Dict[str, Tuple[Dict[str, List[str]], Dict[str, List[str]]]] = {}


def _load_dictionary(csv_path: str) -> Tuple[Dict[str, List[str]], Dict[str, List[str]]]:
    """
    Загружает словарь синонимов и антонимов из CSV файла.
    
    Формат CSV: id, word1, word2, relation_type (S/A)
    Примеры:
        S_0, чистый, белый, S   -> "чистый" и "белый" синонимы
        A_1, чистый, грязный, A -> "чистый" и "грязный" антонимы

    Возвращает два словаря:
        synonyms[word] -> список его синонимов
        antonyms[word] -> список его антонимов
    """
    if csv_path in _DICT_CACHE:
        return _DICT_CACHE[csv_path]

    synonyms: Dict[str, Set[str]] = {}
    antonyms: Dict[str, Set[str]] = {}

    with open(csv_path, encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) < 4:
                continue

            word1 = row[1].lower().strip()
            word2 = row[2].lower().strip()
            rel = row[3].strip().upper()

            if rel == "S":  # Синонимы
                synonyms.setdefault(word1, set()).add(word2)
                synonyms.setdefault(word2, set()).add(word1)
            elif rel == "A":  # Антонимы
                antonyms.setdefault(word1, set()).add(word2)
                antonyms.setdefault(word2, set()).add(word1)

    syn_dict = {k: list(v) for k, v in synonyms.items()}
    ant_dict = {k: list(v) for k, v in antonyms.items()}

    _DICT_CACHE[csv_path] = (syn_dict, ant_dict)
    return syn_dict, ant_dict


def _find_dict_path(dict_path: Optional[str] = None) -> str:
    """
    Находит путь к файлу словаря.
    - если пользователь явно передал dict_path и файл существует → используем его
    - иначе пробуем несколько "типичных" путей
    - если нигде не нашли — выбрасываем ошибку FileNotFoundError
    """
    if dict_path and os.path.exists(dict_path):
        return dict_path

    possible_paths = [
        "data/ant_syn_pairs.csv",
        Path(__file__).parent.parent.parent.parent / "data" / "ant_syn_pairs.csv",
        Path.cwd() / "data" / "ant_syn_pairs.csv",
    ]

    for path in possible_paths:
        abs_path = Path(path).resolve()
        if abs_path.exists():
            return str(abs_path)

    raise FileNotFoundError(
        "Словарь ant_syn_pairs.csv не найден!\n"
        "   Скачайте его с https://github.com/DariaB2001/ruAntSynNet/tree/main/Data\n"
        "   и поместите в папку data/"
    )


# ──────────────────────────────────────────────────────────────
# 2. Глобальные данные
# ──────────────────────────────────────────────────────────────

# Загружаем набор русских стоп-слов (предлоги, союзы, местоимения и т.п.)
# Эти слова мы не хотим аугментировать
_STOP = get_russian_stopwords()


def _preserve_case(original: str, replacement: str) -> str:
    """
    Сохраняет регистр (заглавные/строчные) исходного слова при замене.

    Примеры:
        original = "Дом", replacement = "здание"  -> "Здание"
        original = "дом", replacement = "здание"  -> "здание"
        original = "ДОМ", replacement = "здание"  -> "ЗДАНИЕ"
    """
    if original.isupper():
        return replacement.upper()
    elif original and original[0].isupper():
        return replacement.capitalize()
    return replacement.lower()


# ──────────────────────────────────────────────────────────────
# 3. Аугментатор синонимов
# ──────────────────────────────────────────────────────────────

class RuSynonymAug(RussianWordMixin, naw.WordAugmenter):
    """
    Русский аугментатор замены слов на синонимы по словарю Даши Бородиной.

    Наследование:
        RussianWordMixin — даёт нам русский токенизатор/детокенизатор.
        naw.WordAugmenter — базовая логика nlpaug (выбор индексов, aug_p, aug_min, aug_max и т.п.).

    Параметры конструктора:
        dict_path: путь к CSV файлу (ant_syn_pairs.csv)
        action: тип действия (обычно Action.SUBSTITUTE — замена слов)
        aug_p: вероятность замены каждого подходящего слова
        aug_min: минимальное число замен за раз
        aug_max: максимальное число замен за раз
        stopwords: список стоп-слов; если None — берём наш _STOP
        use_morphology: использовать ли морфологическое согласование форм (stanza + pymorphy2)
        verbose: уровень "болтливости" (0 — тихо, >0 — печатает отладочную инфу)
    """

    def __init__(
        self,
        dict_path: Optional[str] = None,
        action: str = Action.SUBSTITUTE,
        aug_p: float = 0.3,
        aug_min: int = 1,
        aug_max: int = 10,
        stopwords: Optional[List[str]] = None,
        use_morphology: bool = True,  # NEW: включить морфологическое согласование
        verbose: int = 0,
    ):
        # Находим путь к словарю и загружаем его
        self.dict_path = _find_dict_path(dict_path)
        self.synonyms, self.antonyms = _load_dictionary(self.dict_path)

        # Вызываем конструктор родительского класса nlpaug.WordAugmenter
        super().__init__(
            action=action,
            aug_p=aug_p,
            aug_min=aug_min,
            aug_max=aug_max,
            stopwords=stopwords or list(_STOP),
            tokenizer=None,
            reverse_tokenizer=None,
            device="cpu",
            verbose=verbose,
            stopwords_regex=None,
            include_detail=False,
        )

        # Сохраняем флаг морфологии
        # Используем морфологию только если: 1) пользователь хочет, 2) библиотеки доступны
        self.use_morphology = use_morphology and _MORPH_AVAILABLE
        self.verbose = verbose

        if verbose > 0:
            print(f" RuSynonymAug: загружено {len(self.synonyms)} слов с синонимами")
            print(f"   Путь к словарю: {self.dict_path}")
            if self.use_morphology:
                print(f"   Морфология: включена (stanza + pymorphy2)")
            else:
                print(f"   Морфология: выключена")

    def _get_synonyms(self, word: str) -> List[str]:
        """
        Возвращает список синонимов для данного слова.
        Если слова нет в словаре — возвращаем пустой список.
        """
        return self.synonyms.get(word.lower(), [])

    def skip_aug(self, token_idxes, tokens):
        """
        Фильтрует индексы токенов, которые мы потенциально можем аугментировать.
        Отбрасываем:
            - стоп-слова
            - слишком короткие токены (длина <= 1)
            - не буквенные токены (знаки препинания, цифры)
            - токены, у которых нет синонимов в словаре
        """
        return [
            i for i in token_idxes
            if tokens[i].lower() not in self.stopwords
            and len(tokens[i]) > 1
            and tokens[i].isalpha()
            and self._get_synonyms(tokens[i])
        ]

    def substitute(self, data: str) -> str:
        """
        Основная логика замены на синонимы.
        
        Если use_morphology=True:
            - берём синоним из словаря (базовая форма)
            - согласуем его с исходным словом по падежу, роду, числу
            - сохраняем регистр
        Иначе:
            - просто подставляем синоним и сохраняем регистр
        """
        if not data or not data.strip():
            return data

        tokens = ru_tokenize(data)
        if not tokens:
            return data

        # Получаем индексы токенов для аугментации
        idxes = self._get_aug_idxes(tokens)
        if not idxes:
            return data

        # Контекст для морфологии — всё предложение целиком
        ctx = data if self.use_morphology else None

        new_tokens = list(tokens)
        for idx in idxes:
            orig = tokens[idx]  # исходное слово, например "интересным"
            syns = self._get_synonyms(orig)
            if not syns:
                continue

            # Выбираем случайный синоним (это базовая форма из словаря, например "красивый")
            lemma = random.choice(syns)

            # Если морфология включена — согласуем форму
            if self.use_morphology and _MORPH is not None:
                try:
                    # match_form("красивый", "интересным", ctx) -> "красивым"
                    inflected = _MORPH.match_form(lemma, orig, ctx)
                except Exception:
                    # Если что-то пошло не так — используем базовую форму
                    inflected = lemma
            else:
                inflected = lemma

            # Сохраняем регистр (Дом -> Здание, дом -> здание)
            repl = _preserve_case(orig, inflected)
            new_tokens[idx] = repl

        return ru_detokenize(new_tokens)

    def insert(self, data: str) -> str:
        """Для совместимости с nlpaug, но мы используем только substitute()."""
        return data

    def augment(self, data, n: int = 1):
        """Обёртка над substitute для совместимости с nlpaug."""
        if isinstance(data, str):
            if n == 1:
                return self.substitute(data)
            else:
                return [self.substitute(data) for _ in range(n)]
        elif isinstance(data, list):
            return [self.augment(x, n=n) for x in data]
        return data

    def get_statistics(self) -> dict:
        """Возвращает статистику по загруженному словарю."""
        return {
            "synonyms_count": len(self.synonyms),
            "antonyms_count": len(self.antonyms),
            "dict_path": self.dict_path,
            "use_morphology": self.use_morphology,
        }