"""
ru_nlpaug.augmenter.word.word_embs

Русская обёртка над nlpaug.augmenter.word.WordEmbsAug.
Пока только подмена токенизации через RussianWordMixin.
Дальше вы добавите сюда свои словари / морфологию.
"""

"""
ru_nlpaug.augmenter.word.word_embs

Аугментер, основанный на word2vec-эмбеддингах (gensim) с фильтрацией по части
речи и согласованием формы для русского языка.
"""

# ru_nlpaug/augmenter/word/ru_word_embs.py
from pathlib import Path
import random
import re
import os
from typing import List, Optional

from gensim.models import KeyedVectors
import nlpaug.augmenter.word as naw
from nlpaug.util import Action

from ru_nlpaug.augmenter.word.base import RussianWordMixin
from ru_nlpaug.util.text.ru_part_of_speech import analyze_word, RussianMorphology
from ru_nlpaug.util.text.ru_tokenizer import (
    ru_tokenize,
    ru_detokenize,
    get_russian_stopwords,
)


# ──────────────────────────────────────────────────────────────
# 1.  Gensim-обёртка
# ──────────────────────────────────────────────────────────────
class GensimWord2VecModel:
    """Мини-обёртка над gensim.KeyedVectors"""

    def __init__(self, model_path: str, top_k: int = 50):
        path = Path(model_path)
        if not path.exists():
            raise FileNotFoundError(f"Word2Vec model not found: {path}")

        ext = path.suffix.lower()
        if ext == ".bin":
            self.wv = KeyedVectors.load_word2vec_format(path, binary=True)
        elif ext in (".vec", ".txt"):
            self.wv = KeyedVectors.load_word2vec_format(path, binary=False)
        else:  # .model / .kv
            self.wv = KeyedVectors.load(path, mmap="r")

        self.top_k = top_k

    def has_key(self, key: str) -> bool:
        return key in self.wv.key_to_index

    def most_similar_keys(self, key: str, topn: int) -> List[str]:
        try:
            return [k for k, _ in self.wv.most_similar(key, topn=topn)]
        except KeyError:
            return []

    @staticmethod
    def key_to_lemma(key: str) -> str:
        # 'умный_ADJ' → 'умный'
        return key.split("_")[0]


# ──────────────────────────────────────────────────────────────
# 2.  Глобальные данные и утилиты
# ──────────────────────────────────────────────────────────────
_STOP = get_russian_stopwords()
_MORPH = RussianMorphology()


def _is_valid_word(word: str) -> bool:
    """
    Фильтр артефактов / «мусорных» токенов.
    Расширяйте по мере необходимости.
    """
    w = word.lower()
    if len(w) < 2:
        return False
    if re.search(r"[x]{3,}", w):
        return False
    if re.search(r"[бвгджзйклмнпрстфхцчшщ]{4,}", w):
        return False
    if re.match(r"\d", w) or re.search(r"\d{2,}", w):
        return False
    return w


# ──────────────────────────────────────────────────────────────
# 3.  Сам аугментер
# ──────────────────────────────────────────────────────────────
class RuWordEmbsAug(RussianWordMixin, naw.WordAugmenter):
    DEFAULT_MODEL_NAME = "tayga_upos_skipgram_300_2_2019.bin"

    def __init__(
        self,
        models_dir: str = "models",
        model_name: Optional[str] = None,
        *,
        action: str = Action.SUBSTITUTE,
        aug_p: float = 0.3,
        aug_min: int = 1,
        aug_max: int = 10,
        top_k: int = 50,
        stopwords: Optional[List[str]] = None,
        verbose: int = 0,
    ):
        # --------------------------------------------------
        # 1) определяем путь к файлу МГНОВЕННО, чтобы
        #    ниже можно было на него ссылаться без ошибок
        # --------------------------------------------------
        if model_name is None:
            model_name = self.DEFAULT_MODEL_NAME
        self.model_path = os.path.join(models_dir, model_name)

        # --------------------------------------------------
        # 2) родитель-ский конструктор
        # --------------------------------------------------
        super().__init__(
            action=action,
            aug_p=aug_p,
            aug_min=aug_min,
            aug_max=aug_max,
            stopwords=stopwords or _STOP,
            tokenizer=None,
            reverse_tokenizer=None,
            device="cpu",
            verbose=verbose,
            stopwords_regex=None,
            include_detail=False,
        )

        # --------------------------------------------------
        # 3) проверяем наличие файла и загружаем модель
        # --------------------------------------------------
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(
                f"❌ Word2Vec-файл не найден:\n   {self.model_path}\n"
                "Скачайте модель Tayga (bin) и поместите её в указанный каталог."
            )

        if verbose:
            print(f"📦 Загрузка Word2Vec из {self.model_path}")

        self.model = GensimWord2VecModel(self.model_path, top_k=top_k)
        self.top_k = top_k
        
        if verbose:
            print(f"✅ Модель загружена: {len(self.model.wv.key_to_index):,} слов\n")

    # ---------- служебное ----------
    def _key_in_vocab(self, word: str, ctx: str) -> Optional[str]:
        """Возвращает подходящий ключ из векторной модели или None."""
        info = analyze_word(word, ctx)
        lemma, pos = info.get("lemma"), info.get("pos")
        if not lemma or not pos or pos == "X":
            return None

        variants = [
            f"{lemma.lower()}_{pos}",
            f"{lemma}_{pos}",
            f"{lemma.lower()}_{pos.lower()}",
            f"{lemma.lower()}_{pos.upper()}",
        ]
        # Дополнительные POS-варианты
        pos_map = {
            "NOUN": ["S"], "VERB": ["V"], "ADJ": ["A"], "ADV": ["R"],
            "PRON": ["P"], "DET": ["M"],
        }
        for alt in pos_map.get(pos, []):
            variants.append(f"{lemma.lower()}_{alt}")

        return next((k for k in variants if self.model.has_key(k)), None)

    def skip_aug(self, token_idxes, tokens):
        ctx = " ".join(tokens)
        return [
            i for i in token_idxes
            if tokens[i].lower() not in self.stopwords and self._key_in_vocab(tokens[i], ctx)
        ]

    # ---------- substitute ----------
    def substitute(self, data: str) -> str:
        if not data or not data.strip():
            return data

        tokens = ru_tokenize(data)
        ctx = " ".join(tokens)
        idxes = self._get_aug_idxes(tokens)
        if not idxes:
            return data

        for idx in idxes:
            orig = tokens[idx]
            orig_info = analyze_word(orig, ctx)
            orig_key = self._key_in_vocab(orig, ctx)
            if not orig_key:
                continue

            # кандидаты из модели
            cand_keys = self.model.most_similar_keys(orig_key, self.top_k * 3)
            cand_lemmas = [
                self.model.key_to_lemma(k)
                for k in cand_keys
                if k.endswith(f"_{orig_info['pos']}") and
                   _is_valid_word(self.model.key_to_lemma(k)) and
                   self.model.key_to_lemma(k).lower() not in self.stopwords
            ]
            if not cand_lemmas:
                continue

            new_lemma = random.choice(cand_lemmas[:10])
            new_word = _MORPH.match_form(new_lemma, orig, ctx)

            if not _is_valid_word(new_word):
                continue

            if orig[0].isupper():
                new_word = new_word.capitalize()
            tokens[idx] = new_word

        return ru_detokenize(tokens)

    # ---------- insert ----------
    def insert(self, data: str) -> str:
        if not data or not data.strip():
            return data

        tokens = ru_tokenize(data)
        ctx = " ".join(tokens)
        idxes = self._get_random_aug_idxes(tokens)
        if not idxes:
            return data

        idxes.sort(reverse=True)
        for idx in idxes:
            ref = tokens[idx]
            ref_info = analyze_word(ref, ctx)
            ref_key = self._key_in_vocab(ref, ctx)
            if not ref_key:
                continue

            cand_keys = self.model.most_similar_keys(ref_key, self.top_k * 3)
            cand_lemmas = [
                self.model.key_to_lemma(k)
                for k in cand_keys
                if k.endswith(f"_{ref_info['pos']}") and
                   _is_valid_word(self.model.key_to_lemma(k)) and
                   self.model.key_to_lemma(k).lower() not in self.stopwords
            ]
            if not cand_lemmas:
                continue

            ins_lemma = random.choice(cand_lemmas[:10])
            ins_word = _MORPH.match_form(ins_lemma, ref, ctx)

            if not _is_valid_word(ins_word):
                continue

            tokens.insert(idx, ins_word)

        return ru_detokenize(tokens)
    
     # Алиас для совместимости
    def augment(self, data: str) -> str:
        if self.action == Action.INSERT:
            return self.insert(data)
        else:
            return self.substitute(data)