
"""
ru_nlpaug.util.text.part_of_speech

Так выглядит оригинальный код: 
### MODULE: nlpaug.util.text.part_of_speech

class PartOfSpeech:
    NOUN = 'noun'
    VERB = 'verb'
    ADJECTIVE = 'adjective'
    ADVERB = 'adverb'

    pos2con = {
        'n': [
            'NN', 'NNS', 'NNP', 'NNPS',  # from WordNet
            'NP'  # from PPDB
        ],
        'v': [
            'VB', 'VBD', 'VBG', 'VBN', 'VBZ',  # from WordNet
            'VBP'  # from PPDB
        ],
        'a': ['JJ', 'JJR', 'JJS', 'IN'],
        's': ['JJ', 'JJR', 'JJS', 'IN'],  # Adjective Satellite
        'r': ['RB', 'RBR', 'RBS'],  # Adverb
    }

    con2pos = {}
    poses = []
    for key, values in pos2con.items():
        poses.extend(values)
        for value in values:
            if value not in con2pos:
                con2pos[value] = []
            con2pos[value].append(key)

    @staticmethod
    def pos2constituent(pos):
        if pos in PartOfSpeech.pos2con:
            return PartOfSpeech.pos2con[pos]
        return []

    @staticmethod
    def constituent2pos(con):
        if con in PartOfSpeech.con2pos:
            return PartOfSpeech.con2pos[con]
        return []

    @staticmethod
    def get_pos():
        return PartOfSpeech.poses
"""


# ru_nlpaug/util/text/morphology.py
from typing import Dict, Optional
import stanza
import pymorphy2
import torch
_real_torch_load = torch.load

def _patched_torch_load(*args, **kwargs):
    if 'weights_only' not in kwargs:
        # старое поведение до PyTorch 2.6
        kwargs['weights_only'] = False
    return _real_torch_load(*args, **kwargs)

torch.load = _patched_torch_load

import numpy as np
#from torch.serialization import add_safe_globals

#add_safe_globals([np.core.multiarray._reconstruct])

# ───────────── 1. Ленивая инициализация ──────────────
_stanza_pipeline = None
_pymorphy = None

def get_stanza():
    global _stanza_pipeline
    if _stanza_pipeline is None:
        stanza.download('ru', verbose=False)
        _stanza_pipeline = stanza.Pipeline(
            'ru',
            processors='tokenize,pos,lemma',  # mwt обязателен
            verbose=False,
            use_gpu=False
        )
    return _stanza_pipeline

def get_pymorphy():
    global _pymorphy
    if _pymorphy is None:
        _pymorphy = pymorphy2.MorphAnalyzer()
    return _pymorphy


# ───────────── 2. Парсинг features ──────────────
def parse_features(feats: Optional[str]) -> Dict[str, str]:
    if not feats or feats == '_':
        return {}
    return dict(pair.split('=') for pair in feats.split('|') if '=' in pair)


# ───────────── 3. Анализ слова ──────────────
def analyze_word(word: str, context: Optional[str] = None) -> Dict:
    """
    Возвращает словарь:
        {'text': 'кошку', 'lemma': 'кошка',
         'pos': 'NOUN',
         'features': {'Case': 'Acc', 'Gender': 'Fem', 'Number': 'Sing'}}
    """
    pipe = get_stanza()
    text = context if context and word in context else word
    doc = pipe(text)

    wl = word.lower()
    for sent in doc.sentences:
        for token in sent.words:
            if token.text.lower() == wl or not context:
                return {
                    'text': token.text,
                    'lemma': token.lemma,
                    'pos': token.upos,
                    'features': parse_features(token.feats)
                }

    return {'text': word, 'lemma': word, 'pos': 'X', 'features': {}}


# ───────────── 4. Склонение / согласование ──────────────
_MAPPING_UD2MORPHY = {
    'Case':   {'Nom': 'nomn', 'Gen': 'gent', 'Dat': 'datv',
               'Acc': 'accs', 'Ins': 'ablt', 'Loc': 'loct'},
    'Number': {'Sing': 'sing', 'Plur': 'plur'},
    'Gender': {'Masc': 'masc', 'Fem': 'femn', 'Neut': 'neut'},
    'Tense':  {'Past': 'past', 'Pres': 'pres', 'Fut': 'futr'}
}

def inflect_word(word: str, target: Dict[str, str]) -> str:
    morph = get_pymorphy()
    parsed = morph.parse(word)[0]
    grammemes = { _MAPPING_UD2MORPHY[t][v]
                  for t, v in target.items()
                  if t in _MAPPING_UD2MORPHY and v in _MAPPING_UD2MORPHY[t] }
    if grammemes:
        inf = parsed.inflect(grammemes)
        if inf:
            return inf.word
    return word

def match_morphology(target: str, source: str, ctx: Optional[str] = None) -> str:
    src_info = analyze_word(source, ctx)
    result   = inflect_word(target, src_info['features'])

    # сохраняем регистр
    if source[0].isupper():
        result = result.capitalize()
    if source.isupper():
        result = result.upper()
    return result


# ───────────── 5. Удобная обёртка ──────────────
class RussianMorphology:
    """Лёгкий объект-прокси для аугментеров."""
    def lemmatize(self, word: str, ctx: Optional[str] = None) -> str:
        return analyze_word(word, ctx)['lemma']

    def get_pos(self, word: str, ctx: Optional[str] = None) -> str:
        return analyze_word(word, ctx)['pos']

    def match_form(self, target: str, source: str,
                   ctx: Optional[str] = None) -> str:
        return match_morphology(target, source, ctx)