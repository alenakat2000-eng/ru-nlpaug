"""
ru_nlpaug.augmenter.word.ru_antonym

Русский аугментатор замены слов на антонимы.
Использует словарь антонимов из репозитория Даши Бородиной (ruAntSynNet).
Поддерживает морфологическое согласование форм через RussianMorphology.
"""

import random
from typing import List, Optional

import nlpaug.augmenter.word as naw
from nlpaug.util import Action

from ru_nlpaug.augmenter.word.base import RussianWordMixin
from ru_nlpaug.util.text.ru_tokenizer import (
    ru_tokenize,
    ru_detokenize,
    get_russian_stopwords,
)

# Импортируем общие функции из ru_synonym (чтобы не дублировать код)
from ru_nlpaug.augmenter.word.ru_synonym import (
    _load_dictionary,
    _find_dict_path,
    _preserve_case,
)

# ──────────────────────────────────────────────────────────────
# Попытка импорта морфологии (stanza + pymorphy2)
# Если не установлены — работаем без согласования форм
# ──────────────────────────────────────────────────────────────
try:
    from ru_nlpaug.util.text.ru_part_of_speech import RussianMorphology
    _MORPH = RussianMorphology()
    _MORPH_AVAILABLE = True
except ImportError:
    _MORPH = None
    _MORPH_AVAILABLE = False


_STOP = get_russian_stopwords()


class RuAntonymAug(RussianWordMixin, naw.WordAugmenter):
    """
    Русский аугментатор замены слов на антонимы по словарю Даши Бородиной.

    ⚠ ВНИМАНИЕ: Меняет смысл предложения на противоположный!

    Параметры конструктора:
        dict_path: путь к CSV файлу (ant_syn_pairs.csv)
        action: тип действия (обычно Action.SUBSTITUTE — замена слов)
        aug_p: вероятность замены каждого подходящего слова
        aug_min: минимальное число замен за раз
        aug_max: максимальное число замен за раз
        stopwords: список стоп-слов; если None — берём наш _STOP
        use_morphology: использовать ли морфологическое согласование форм (stanza + pymorphy2)
        verbose: уровень "болтливости" (0 — тихо, >0 — печатает отладочную инфу)
    """

    def __init__(
        self,
        dict_path: Optional[str] = None,
        action: str = Action.SUBSTITUTE,
        aug_p: float = 0.3,
        aug_min: int = 1,
        aug_max: int = 10,
        stopwords: Optional[List[str]] = None,
        use_morphology: bool = True,  # NEW: включить морфологическое согласование
        verbose: int = 0,
    ):
        self.dict_path = _find_dict_path(dict_path)
        self.synonyms, self.antonyms = _load_dictionary(self.dict_path)

        super().__init__(
            action=action,
            aug_p=aug_p,
            aug_min=aug_min,
            aug_max=aug_max,
            stopwords=stopwords or list(_STOP),
            tokenizer=None,
            reverse_tokenizer=None,
            device="cpu",
            verbose=verbose,
            stopwords_regex=None,
            include_detail=False,
        )

        # Используем морфологию только если: 1) пользователь хочет, 2) библиотеки доступны
        self.use_morphology = use_morphology and _MORPH_AVAILABLE
        self.verbose = verbose

        if verbose > 0:
            print(f" RuAntonymAug: загружено {len(self.antonyms)} слов с антонимами")
            print(f"   Путь к словарю: {self.dict_path}")
            if self.use_morphology:
                print(f"   Морфология: включена (stanza + pymorphy2)")
            else:
                print(f"   Морфология: выключена")

    def _get_antonyms(self, word: str) -> List[str]:
        """
        Возвращает список антонимов для данного слова.
        Если слова нет в словаре — возвращаем пустой список.
        """
        return self.antonyms.get(word.lower(), [])

    def skip_aug(self, token_idxes, tokens):
        """
        Фильтрует индексы токенов, которые мы потенциально можем аугментировать.
        Отбрасываем:
            - стоп-слова
            - слишком короткие токены (длина <= 1)
            - не буквенные токены (знаки препинания, цифры)
            - токены, у которых нет антонимов в словаре
        """
        return [
            i for i in token_idxes
            if tokens[i].lower() not in self.stopwords
            and len(tokens[i]) > 1
            and tokens[i].isalpha()
            and self._get_antonyms(tokens[i])
        ]

    def substitute(self, data: str) -> str:
        """
        Основная логика замены на антонимы.
        
        Если use_morphology=True:
            - берём антоним из словаря (базовая форма)
            - согласуем его с исходным словом по падежу, роду, числу
            - сохраняем регистр
        Иначе:
            - просто подставляем антоним и сохраняем регистр
        """
        if not data or not data.strip():
            return data

        tokens = ru_tokenize(data)
        if not tokens:
            return data

        idxes = self._get_aug_idxes(tokens)
        if not idxes:
            return data

        # Контекст для морфологии — всё предложение целиком
        ctx = data if self.use_morphology else None

        new_tokens = list(tokens)
        for idx in idxes:
            orig = tokens[idx]  # исходное слово, например "чистым"
            ants = self._get_antonyms(orig)
            if not ants:
                continue

            # Выбираем случайный антоним (базовая форма из словаря, например "грязный")
            lemma = random.choice(ants)

            # Если морфология включена — согласуем форму
            if self.use_morphology and _MORPH is not None:
                try:
                    # match_form("грязный", "чистым", ctx) -> "грязным"
                    inflected = _MORPH.match_form(lemma, orig, ctx)
                except Exception:
                    inflected = lemma
            else:
                inflected = lemma

            # Сохраняем регистр
            repl = _preserve_case(orig, inflected)
            new_tokens[idx] = repl

        return ru_detokenize(new_tokens)

    def insert(self, data: str) -> str:
        """Для совместимости с nlpaug."""
        return data

    def augment(self, data, n: int = 1):
        """Обёртка над substitute для совместимости с nlpaug."""
        if isinstance(data, str):
            if n == 1:
                return self.substitute(data)
            else:
                return [self.substitute(data) for _ in range(n)]
        elif isinstance(data, list):
            return [self.augment(x, n=n) for x in data]
        return data

    def get_statistics(self) -> dict:
        """Возвращает статистику по загруженному словарю."""
        return {
            "synonyms_count": len(self.synonyms),
            "antonyms_count": len(self.antonyms),
            "dict_path": self.dict_path,
            "use_morphology": self.use_morphology,
        }